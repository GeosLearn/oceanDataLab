# COVE
COastal Vector Evolution Model - A vector-based coastline evolution model
